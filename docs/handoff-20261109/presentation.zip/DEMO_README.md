# UnionMimic 展示材料

先播放 `unionmimic/work/demos/unionmimic-geometry-story-20261109-v1/unionmimic-geometry-story.mp4`（52秒）。

随后可单独播放30秒 `unionmimic/work/demos/geometry-live-20261109-v1/geometry-demo.mp4`，以及 Sharpa 单轴/多轴运动学参考预览。文件和来源见 `showcase.csv`。

展示结论：历史 SM 学会了角块单轴旋转；冻结 WM-Craftnet 编码器有可读出的几何信息。几何估计仅显示，未反馈策略；转笔预览是运动学播放。不能把这些片段称为先验改善控制或完整转笔适配。

`learning-coverage.png` 是此前截止时刻的历史图，仅包含当时的 PPO 早期点。最新 SM/PPO 最终评估 JSON 已补入本包，见 `showcase.csv`。单训练种子的开发评估尚不证明论文加速比。

生成脚本、研究文档和来源manifest随包保留。小包不含所有原始轨迹与大检查点；完整内容在大分卷。原始源码中的绝对路径仍保留作为来源记录；本地再生成时设置新的输出路径，并安装文档要求的环境/字体。

校验：解压后运行 `sha256sum -c PRESENTATION_SHA256SUMS`（macOS用 `shasum -a 256 -c`）。
